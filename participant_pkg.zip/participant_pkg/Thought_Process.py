#Thought Process & Solution Draft – Contact Saver Project 

#1. Understanding the Problem 
#You are organizing a short tech workshop.
#You need to collect details of participants: 
#-Name, Age, Phone Number, Track (e.g., Web, Data, AI) 
#These details must be saved into a CSV file for later use by the organizers. 
#Core Idea: Build a small Python program that accepts inputs, validates them, and stores them neatly in a CSV file. 

#Step-by-Step Plan Step 
# 1: Project Setup 
# -Create a package folder: participant_pkg/
# - __init__.py file_ops.py 
# • In file_ops.py define helper functions: def save_participant(path, participant_dict): # append participant details into a CSV file def load_participants(path): # read all participants from CSV into list of dicts

